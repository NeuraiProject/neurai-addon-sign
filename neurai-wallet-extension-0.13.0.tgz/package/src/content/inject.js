// Neurai Wallet - Page-facing API (runs in MAIN world)
// This file is injected by content.js into the page context
// so that window.neuraiWallet is visible to the page's JavaScript.

(function() {
  'use strict';

  // Internal: send request to content script and wait for response
  var _requestId = 0;
  var _pending = {};

  function _request(action, data, timeoutMs) {
    return new Promise(function(resolve, reject) {
      var id = 'nw_' + (++_requestId) + '_' + Math.random().toString(36).substr(2, 6);
      _pending[id] = { resolve: resolve, reject: reject };

      document.dispatchEvent(new CustomEvent('neuraiWallet_request', {
        detail: { requestId: id, action: action, data: data || {} }
      }));

      // Default timeout is short for read-only actions, but signing flows
      // can legitimately take much longer because they may require popup
      // approval, device selection and physical confirmation on the HW.
      setTimeout(function() {
        if (_pending[id]) {
          delete _pending[id];
          reject(new Error('Request timed out'));
        }
      }, timeoutMs || 30000);
    });
  }

  // Listen for responses from content script
  document.addEventListener('neuraiWallet_response', function(e) {
    var detail = e.detail;
    var handler = _pending[detail.requestId];
    if (!handler) return;
    delete _pending[detail.requestId];

    if (detail.error) {
      handler.reject(new Error(detail.error));
    } else {
      handler.resolve(detail.result);
    }
  });

  // Expose API to the page
  window.neuraiWallet = {
    isInstalled: true,
    version: '0.13.0',

    getAddress: function() {
      return _request('getAddress');
    },

    getPublicKey: function() {
      return _request('getPublicKey');
    },

    isConnected: function() {
      return _request('isConnected');
    },

    signMessage: function(message) {
      if (!message || typeof message !== 'string') {
        return Promise.reject(new Error('Message must be a non-empty string'));
      }
      return _request('signMessage', { message: message }, 180000);
    },

    verifyMessage: function(address, message, signature) {
      return _request('verifyMessage', { address: address, message: message, signature: signature });
    },

    /**
     * Sign a raw transaction hex using the wallet's private key via the Neurai RPC.
     * @param {string} txHex - Unsigned (or partially signed) raw transaction hex
     * @param {Array} utxos - Array of {txid, vout, scriptPubKey, amount[, bareScriptHint]}
     *                        for inputs being signed. `bareScriptHint` is optional and unlocks
     *                        signing of partial-fill covenant cancel prevouts. Shape:
     *                          `{ kind: 'covenant-cancel-legacy', covenantScriptHex: string }`
     *                          `{ kind: 'covenant-cancel-pq',     covenantScriptHex: string }`
     *                        `covenantScriptHex` must be the bytes of the partial-fill covenant
     *                        whose `taggedHash("NeuraiAuthScript", 0x01||0x00||SHA256(cov))`
     *                        equals the prevout's AuthScript-v1 commitment. The DEX that built
     *                        the covenant supplies these bytes. Any other hint shape is rejected.
     * @param {string} sighashType - e.g. 'ALL', 'SINGLE|ANYONECANPAY'
     * @returns {Promise<{signedTxHex: string, complete: boolean}>}
     */
    signRawTransaction: function(txHex, utxos, sighashType) {
      if (!txHex || typeof txHex !== 'string') {
        return Promise.reject(new Error('txHex must be a non-empty string'));
      }
      return _request('signRawTransaction', { txHex: txHex, utxos: utxos || [], sighashType: sighashType || 'ALL' }, 180000);
    },

    getInfo: function() {
      return _request('getInfo');
    }
  };

  // Notify the page that the API is ready
  document.dispatchEvent(new CustomEvent('neuraiWalletReady', {
    detail: { isInstalled: true, version: '0.13.0' }
  }));
})();
